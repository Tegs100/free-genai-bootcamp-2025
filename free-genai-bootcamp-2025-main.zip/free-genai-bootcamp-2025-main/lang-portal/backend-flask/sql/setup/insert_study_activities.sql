INSERT INTO study_activities (name, url, preview_url) VALUES 
('Typing Tutor', 'http://localhost:8080', '/assets/study_activities/typing_tutor.png');
